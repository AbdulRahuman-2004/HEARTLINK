# SecretBond — website prototype

A mobile-friendly, single-file prototype for the SecretBond personalized surprise website.

## Open it
1. Extract `secretbond-website.zip`.
2. Open `index.html` in Chrome, Edge, or Firefox.
3. Click **Create Your Surprise**, fill the form, and submit a demo order.
4. Click **Open demo admin review** to approve the order locally.
5. Open the generated receiver link from the demo admin view and test the secret-code flow.

## Important prototype limitations
This is a front-end demo, not a production payment or privacy system.
- Orders are stored in the current browser's `localStorage` only.
- The demo admin has no secure login.
- The QR area is a placeholder. Replace it with your real UPI QR only after deciding how to verify payments.
- Demo approval is not payment verification.
- The access code and messages are not protected by a server in this static version. Do not use it for real private messages or publish it as a secure service.
- WhatsApp opens a prefilled message; the sender must press Send. It does not confirm delivery.
- The sample library is a starter collection, not the requested 300-message production library.

## To launch publicly
Build a real backend (for example Next.js API routes + Supabase), store secrets server-side, hash access codes, enforce rate limits, use database access policies, and verify payments using a supported payment provider or a manual admin review flow. Set up secure admin authentication, privacy policy, terms, refund policy, and data-retention rules. Do not put service-role keys or payment secrets in browser code.

## Main features in this demo
- Landing page and ₹1 / ₹5 / ₹10 plan cards.
- Relationship-specific theme colors and copy.
- Sender/receiver form with word limits.
- Live preview.
- Demo payment reference submission and pending status.
- Demo admin approve/reject workflow.
- Receiver URL and code-entry experience.
- Secret-message reveal after code entry in the demo.
- WhatsApp click-to-chat link preparation.
- Searchable starter message library.
- Export and clear local demo orders.
