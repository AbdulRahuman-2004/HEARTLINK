-- Production schema starter. Review and adapt before deployment.
create table if not exists public.plans (
  id text primary key check (id in ('mini','special','unlimited')),
  name text not null,
  price_inr integer not null check (price_inr in (1,5,10)),
  active boolean not null default true
);
insert into public.plans(id,name,price_inr) values
 ('mini','Mini Surprise',1),('special','Special Surprise',5),('unlimited','Unlimited Surprise',10)
on conflict (id) do nothing;

create table if not exists public.surprises (
  id uuid primary key default gen_random_uuid(),
  public_token text unique not null,
  sender_name text not null,
  receiver_name text not null,
  receiver_phone text not null,
  relationship text not null,
  plan_id text not null references public.plans(id),
  main_message text not null,
  secret_message_ciphertext text not null,
  access_code_hash text not null,
  status text not null default 'pending_payment'
    check (status in ('pending_payment','pending_verification','active','rejected','expired')),
  expires_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  surprise_id uuid not null references public.surprises(id) on delete cascade,
  amount_inr integer not null check (amount_inr in (1,5,10)),
  payment_status text not null default 'pending'
    check (payment_status in ('pending','pending_verification','verified','rejected','refunded')),
  upi_reference text,
  verified_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.share_events (
  id uuid primary key default gen_random_uuid(),
  surprise_id uuid not null references public.surprises(id) on delete cascade,
  method text not null default 'whatsapp_click_to_chat',
  status text not null default 'link_prepared',
  created_at timestamptz not null default now()
);

-- Enable RLS. Production policies and server-only writes must be added before launch.
alter table public.plans enable row level security;
alter table public.surprises enable row level security;
alter table public.orders enable row level security;
alter table public.share_events enable row level security;
